# -*- coding: utf-8 -*-

import os
import random
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import torch
import argparse
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

from model_PPO import PPO
from env_parallel_parking import Environment
from utils import (
    str2bool,
    visualize_training_loss,
    visualize_test_rewards,
    visualize_detail_reward,
    evaluate_policy
)


def get_args():

    parser = argparse.ArgumentParser()

    parser.add_argument('--n-action', type=int, default=1)
    parser.add_argument('--n-hidden-state', type=int, default=128)

    parser.add_argument('--Max_train_steps', type=int, default=int(1e6))
    parser.add_argument('--save_interval', type=int, default=int(1e6))
    parser.add_argument('--eval_interval', type=int, default=int(1000))
    # parser.add_argument('--update_every', type=int, default=50)

    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--lmbda', type=float, default=0.99)
    parser.add_argument('--eps', type=float, default=0.2)
    parser.add_argument('--num_episodes', type=int, default=500)

    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--actor_lr', type=float, default=3e-5)
    parser.add_argument('--critic_lr', type=float, default=3e-5)
    parser.add_argument('--batch_size', type=int, default=256)
    parser.add_argument('--buffer_size', type=int, default=1e5)

    parser.add_argument('--distance', type=float, default=1000)
    parser.add_argument('--speed', type=float, default=-1)

    args = parser.parse_args()

    return args


def beam_search(agent, env, search_num=10, max_frames=150, explore_rate=0.2):

    reach_num, returns, costs = 0, [], []

    transition_dict = {
        'states': [[] for _ in range(search_num)],
        'actions': [[] for _ in range(search_num)],
        'next_states': [[] for _ in range(search_num)],
        'rewards': [[] for _ in range(search_num)],
        'dones': [[] for _ in range(search_num)],
    }

    for index in range(search_num):

        state, done = env.reset(), False
        t, episode_return = 0, [0 for _ in range(4)]

        for step in range(max_frames):

            if not done:
                if random.random() < explore_rate:
                    action = env.sample()
                else:
                    # action: batch x action_dim
                    action, _ = agent.take_action(state, deterministic=False)
                    action = action[0]

                action_ = [action[0], 100, -3]
                next_state, reward, done = env.step(action_)
                if done and reward > 0:
                    reach_num += 1
                t += 1

                # if done:
                #     print(reward)

            transition_dict['states'][index].append(state)
            transition_dict['actions'][index].append(action)
            transition_dict['next_states'][index].append(next_state)
            transition_dict['rewards'][index].append([reward])
            transition_dict['dones'][index].append([done])

            state = next_state

            if not done:
                _, detail_rewards = env.calculate_detail_reward()
                episode_return[0] += reward
                for i, r in enumerate(detail_rewards):
                    episode_return[i + 1] = r

        returns.append(episode_return)
        costs.append(t)

    return transition_dict, returns, costs, reach_num


def training(args, agent, env):

    num_episodes = args.num_episodes

    actor_loss_list, critic_loss_list = [], []
    costs_list, return_list, reach_num_list = [], [], []

    with tqdm(total=int(num_episodes), desc='Iteration 1') as pbar:

        for i_episode in range(int(num_episodes)):

            transition_dict, returns, costs, reach_num = beam_search(
                agent=agent,
                env=env,
                max_frames=120,
                search_num=10,
                explore_rate=max(0.1, (1 - i_episode / num_episodes) ** (1 / 2))
            )

            actor_loss, critic_loss = agent.update(transition_dict)

            actor_loss_list.append(actor_loss)
            critic_loss_list.append(critic_loss)

            costs_list.append(costs)
            return_list.append(returns[0])
            reach_num_list.append(reach_num)

            if (i_episode + 1) % 10 == 0:
                pbar.set_postfix({
                    # 'episode': '%d' % (num_episodes / 10 * i + i_episode + 1),
                    'cost': '%.2f' % np.mean(costs_list[-10:]),
                    'return': '%.3f' % np.mean(return_list[-10:]),
                    'reach': '%.1f' % np.mean(reach_num_list[-10:])
                })

            if i_episode > 0 and (i_episode % 500) == 0:
                agent.save(
                    output_dir="./chkpt",
                    name=f"step{i_episode}"
                )

            pbar.update(1)

    details = {
        "return_list": return_list,
        "costs_list": costs_list,
        "reach_num_list": reach_num_list,
        "actor_loss_list": actor_loss_list,
        "critic_loss_list": critic_loss_list,
    }

    return agent, details


if __name__ == "__main__":

    args = get_args()

    env = Environment()
    agent = PPO(
        state_dim=env.n_state,
        action_dim=args.n_action,
        hidden_dim=args.n_hidden_state,
        actor_lr=args.actor_lr,
        critic_lr=args.critic_lr,
        lmbda=args.lmbda,
        epochs=args.epochs,
        eps=args.eps,
        gamma=args.gamma,
        device=torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"),
    )

    print(">>> Cuda available:", torch.cuda.is_available())

    agent, detail = training(args, env=env, agent=agent)
    visualize_training_loss(detail)
    visualize_detail_reward(detail["return_list"])

    agent.save(output_dir="./chkpt", name="demo")
    agent.load(output_dir="./chkpt", name="demo")

    avg_step, avg_score, reward_list = evaluate_policy(env, agent=agent, render=True, turns=10)
    print(f"Average step: {avg_step:.2f}\t Average score: {avg_score:.2f}")

    env.close()

    visualize_detail_reward(reward_list[0])
