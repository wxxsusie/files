import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

import numpy as np


class PolicyNet(nn.Module):

    def __init__(self, state_dim, hidden_dim, action_dim, std=0.0):
        super(PolicyNet, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, action_dim)

        self.log_std = nn.Parameter(torch.ones(1, action_dim) * std)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        mu = F.tanh(self.fc2(x))  # 映射到[-1, 1]
        std = self.log_std.exp().expand_as(mu)
        return mu, std


class ValueNet(nn.Module):

    def __init__(self, state_dim, hidden_dim):
        super(ValueNet, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)

        return x


class PPO(nn.Module):

    def __init__(self, state_dim, action_dim, hidden_dim, gamma, lmbda, eps, actor_lr, critic_lr, epochs, device,
                 **kwargs):

        super(PPO, self).__init__()

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim

        self.actor = PolicyNet(state_dim, hidden_dim, action_dim).to(device)
        self.critic = ValueNet(state_dim, hidden_dim).to(device)

        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=critic_lr)

        self.gamma = gamma
        self.lmbda = lmbda
        self.epochs = epochs  # 一条序列的数据用来训练轮数
        self.eps = eps  # PPO中截断范围的参数
        self.device = device

        self.action_scale = 2.0
        self.action_bias = 0.0

    def take_action(self, state, deterministic=False):

        state = torch.FloatTensor(state).to(self.device)
        if len(state.shape) == 1:
            state = state.unsqueeze(0)

        mu, std = self.actor(state)
        mu = mu * self.action_scale + self.action_bias

        if deterministic:
            return mu.detach().cpu().numpy(), None

        dist = Normal(mu, std)
        action = dist.sample()
        log_prob = dist.log_prob(action)

        return action.cpu().numpy(), log_prob

    def calculate_action_log_probs(self, state, action):

        mu, std = self.actor(state)
        mu = mu * self.action_scale + self.action_bias
        dist = Normal(mu, std)
        log_prob = dist.log_prob(action)

        return log_prob

    def compute_advantage(self, td_delta):

        td_delta = td_delta.detach().numpy()
        advantage_list = []
        advantage = 0.0

        for delta in td_delta[::-1]:
            advantage = self.gamma * self.lmbda * advantage + delta
            advantage_list.append(advantage)
        advantage_list.reverse()

        return torch.tensor(advantage_list, dtype=torch.float)

    def compute_advantage_gae(self, next_value, rewards, masks, values):
        gae = 0
        returns = []

        for step in reversed(range(len(rewards))):
            delta = rewards[step] + self.gamma * next_value * masks[step] - values[step]
            gae = delta + self.gamma * self.lmbda * masks[step] * gae
            returns.insert(0, gae + values[step])
            next_value = values[step]
        normed_returns = []

        for ret in returns:
            ret = (ret - ret.mean()) / (ret.std() + 1e-5)
            ret = ret.unsqueeze(0)
            normed_returns.append(ret)

        normed_returns = torch.cat(normed_returns)

        return normed_returns

    def update(self, transition_dict):

        # batch x timestep x state_dim
        states = torch.FloatTensor(transition_dict["states"]).to(self.device)
        next_states = torch.FloatTensor(transition_dict["next_states"]).to(self.device)

        # batch x timestep x 1
        actions = torch.FloatTensor(transition_dict["actions"]).to(self.device)
        rewards = torch.FloatTensor(transition_dict["rewards"]).to(self.device)
        dones = torch.FloatTensor(transition_dict["dones"]).to(self.device)

        states, next_states = states.transpose(0, 1), next_states.transpose(0, 1)
        actions, rewards, dones = actions.transpose(0, 1), rewards.transpose(0, 1), dones.transpose(0, 1)

        assert actions.shape[-1] == 1, f"Error shape for actions: {actions.shape}"
        assert rewards.shape[-1] == 1, f"Error shape for rewards: {rewards.shape}"
        assert dones.shape[-1] == 1, f"Error shape for dones: {dones.shape}"

        old_log_probs = self.calculate_action_log_probs(states, actions).detach()

        # 方案 - 1 (优秀！）
        # 参考：https://github.com/datawhalechina/joyrl-book/blob/main/notebooks/%E7%AC%AC12%E7%AB%A0_PPO_Pendulum-v1.ipynb
        next_value = self.critic(next_states)[-1]
        values = self.critic(states).detach()
        returns = self.compute_advantage_gae(
            next_value=next_value, rewards=rewards, masks=(1 - dones), values=values
        ).detach()

        advantage = returns - values
        target = returns

        # 方案 - 2 （一般）
        # td_target = rewards + self.gamma * self.critic(next_states) * (1 - dones)
        # td_delta = td_target - self.critic(states)

        # advantage = self.compute_advantage(td_delta.cpu()).to(self.device)
        # target = td_target.detach()

        actor_loss_list, critic_loss_list = [], []

        for _ in range(self.epochs):

            new_log_probs = self.calculate_action_log_probs(states, actions)
            ratio = torch.exp(new_log_probs - old_log_probs)

            surr1 = ratio * advantage
            surr2 = torch.clamp(ratio, 1 - self.eps, 1 + self.eps) * advantage

            actor_loss = - torch.min(surr1, surr2).mean()
            critic_loss = torch.mean(F.mse_loss(self.critic(states), target))

            self.actor_optimizer.zero_grad()
            self.critic_optimizer.zero_grad()

            actor_loss_list.append(actor_loss.item())
            critic_loss_list.append(critic_loss.item())

            loss = 0.5 * critic_loss + actor_loss # - 0.001 * entropy
            loss.backward()

            # actor_loss.backward()  # 计算策略网络的梯度
            # critic_loss.backward()  # 计算价值网络的梯度

            for param in self.actor.parameters():
                param.grad.data.clamp_(-1, 1)

            for param in self.critic.parameters():
                param.grad.data.clamp_(-1, 1)

            self.actor_optimizer.step()  # 更新策略网络的参数
            self.critic_optimizer.step()  # 更新价值网络的参数

        return np.mean(actor_loss_list), np.mean(critic_loss_list)

    def save(self, output_dir, name):
        torch.save(self.actor.state_dict(), os.path.join(output_dir, f"actor_{name}.pt"))
        torch.save(self.critic.state_dict(), os.path.join(output_dir, f"critic_{name}.pt"))

    def load(self, output_dir, name):
        self.actor.load_state_dict(torch.load(os.path.join(output_dir, f"actor_{name}.pt")))
        self.critic.load_state_dict(torch.load(os.path.join(output_dir, f"critic_{name}.pt")))