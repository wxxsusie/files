# -*- coding: utf-8 -*-

import pygame
import random
import numpy as np

class ParkedCar(pygame.sprite.Sprite):
    def __init__(self, screen, info, *grps):
        super().__init__(*grps)

        self.screen=screen
        self.width=50
        self.height=90
        self.x,self.y,self.forward_angle=info

        self.image=pygame.image.load('assets/car_other.png').convert_alpha()
        self.image=pygame.transform.scale(self.image, (self.width, self.height))

        self.image=pygame.transform.rotate(self.image, self.forward_angle) # 旋转角度
        self.rect=self.image.get_rect(center=(self.x,self.y))	#画图设置
        self.mask=pygame.mask.from_surface(self.image) #碰撞遮罩


class Boundary_rect(pygame.sprite.Sprite):
    def __init__(self, screen, *grps):
        super().__init__(*grps)

        w=screen.get_width()
        h=screen.get_height()

        self.image = pygame.Surface((w,h),pygame.SRCALPHA) #新建
        self.rect=self.image.get_rect(center=(w/2,h/2)) #必须是画布中心
        pygame.draw.rect(self.image,(220,220,220),self.rect,5) #画矩形
        self.mask=pygame.mask.from_surface(self.image)


class Parking_space():
    def __init__(self, screen, info, color):
        super().__init__()

        space_width=44
        space_height=100
        self.x, self.y, self.forward_angle = info

        space_color=color

        self.image=pygame.Surface((space_width, space_height), pygame.SRCALPHA)
        pos=(space_width/2,space_height/2)

        self.rect=self.image.get_rect(center=pos)
        self.image.fill(space_color)
        pygame.draw.rect(self.image, space_color, self.rect, 3)

        self.rect=self.image.get_rect(center=(self.x,self.y))
        self.mask=pygame.mask.from_surface(self.image)

        self.target_w, self.target_h = 4, 4
        self.target_rect_1 = pygame.Rect((pos[0]-self.target_w/2, pos[1]-self.target_h/2-5),(self.target_w, self.target_h)) # 目标矩形1
        self.target_rect_2 = pygame.Rect((pos[0]-self.target_w/2, pos[1]-self.target_h/2+10),(self.target_w, self.target_h)) # 目标矩形2

        if space_color=='#00FF00':
            pygame.draw.rect(self.image, '#0033FF',self.target_rect_1,1)
            pygame.draw.rect(self.image, '#0033FF',self.target_rect_2,1)

            self.target_x_1=self.x-self.target_w/2
            self.target_y_1=self.y-self.target_h/2-5

            self.target_x_2=self.x-self.target_w/2
            self.target_y_2=self.y-self.target_h/2+10

    def draw(self, screen):
        screen.blit(self.image,self.rect)


class Line_rect(pygame.sprite.Sprite):

    def __init__(self, length, random_pos, color, angle, *grps):
        super().__init__(*grps)

        space_width = length
        space_height = 4
        self.color = color
        self.image = pygame.Surface((space_width, space_height), pygame.SRCALPHA)
        pos = (space_width / 2, space_height / 2)

        self.rect = self.image.get_rect(center=pos)
        pygame.draw.rect(self.image, pygame.Color(color),self.rect,4)

        self.image = pygame.transform.rotate(self.image, angle)

        self.rect = self.image.get_rect(center=random_pos)
        self.mask = pygame.mask.from_surface(self.image)