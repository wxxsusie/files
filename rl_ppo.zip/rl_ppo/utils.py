# -*- coding: utf-8 -*-

import os
import pygame
import argparse
import numpy as np
import matplotlib.pyplot as plt


def moving_average(a, window_size):
    cumulative_sum = np.cumsum(np.insert(a, 0, 0))
    middle = (cumulative_sum[window_size:] - cumulative_sum[:-window_size]) / window_size

    r = np.arange(1, window_size - 1, 2)
    begin = np.cumsum(a[:window_size - 1])[::2] / r
    end = (np.cumsum(a[:-window_size:-1])[::2] / r)[::-1]

    return np.concatenate((begin, middle, end))


def visualize_training_loss(detail):

    actor_loss_list = [np.mean(record) for record in detail["actor_loss_list"]]
    critic_loss_list = [np.mean(record) for record in detail["critic_loss_list"]]
    steps = list(range(len(actor_loss_list)))

    plt.plot(steps, actor_loss_list, label="Actor")
    plt.plot(steps, critic_loss_list, label="Critic")
    plt.xlabel("Steps")
    plt.ylabel("Loss")
    plt.legend()
    plt.show()


def visualize_test_rewards(rewards):

    reward_name = ["total", "distance", "angle"]
    n_reward = len(rewards[0])
    steps = list(range(len(rewards)))
    for i in range(n_reward):
        plt.plot(steps,[reward[i] for reward in rewards], label=reward_name[i])

    plt.xlabel("Steps")
    plt.ylabel("Rewards")
    plt.legend()
    plt.show()


def visualize_detail_reward(reward_list, output_path=""):

    temp = [[] for _ in range(len(reward_list[0]))]
    for line in reward_list:
        for i in range(len(line)):
            temp[i].append(line[i])
    reward_list = temp
    reward_name = ["Total", "Distance", "Angle", "Closer"]

    # 创建一个2x3的画布
    fig, axs = plt.subplots(2, 2)

    # 对每个子图进行操作
    for i in range(2):
        for j in range(2):
            index = i * 2 + j

            if index >= len(reward_list):
                break

            label = f"Reward-{reward_name[index]}"
            reward = moving_average(reward_list[index], window_size=11)
            timestep = list(range(len(reward)))

            axs[i, j].plot(timestep, reward)
            axs[i, j].set_xlabel("Training Times(s)")
            axs[i, j].set_ylabel(label)
            # axs[i, j].set_title("title")

    # 调整每个子图之间的间距
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path)
    # 显示画布
    plt.show()


def evaluate_policy(env, agent, render=False, turns=3):

    agent.eval()

    total_scores = 0
    clock = pygame.time.Clock()
    fps = 60
    steps = 0
    reward_list = []

    for j in range(turns):

        state, done, rewards = env.reset(), False, []
        while not done:

            # for event in pygame.event.get():
            #     if event.type == pygame.QUIT:
            #         running = False

            action, _ = agent.take_action(state, deterministic=False)
            # action: batch_size x action_dim

            action_ = [action[0][0], 100, -2]
            next_state, reward, dw = env.step(action_)
            _, detail_rewards = env.calculate_detail_reward()
            detail_rewards = [reward] + detail_rewards
            done = (dw)

            total_scores += reward
            rewards.append(detail_rewards)

            state = next_state
            if render:
                env.render()

            clock.tick(fps)
            steps += 1

        reward_list.append(rewards)

    avg_steps = steps / turns
    avg_scores = total_scores / turns

    return avg_steps, avg_scores, reward_list


def str2bool(v):
    if isinstance(v, bool):
        return v

    if v.lower() in ('yes', 'True', 'true', 'TRUE', 't', 'y', '1'):
        return True
    else:
        raise argparse.ArgumentTypeError('Boolean')
