# -*- coding: utf-8 -*-

import pygame
import math
import numpy as np

WIDTH_BIAS = 25
HEIGHT_BIAS = 45


class Car(pygame.sprite.Sprite):
    def __init__(self, screen, *grps):
        super().__init__()

        self.screen = screen
        self.width = 38.5
        self.height = 94.5
        self.wheelbase = 55.98
        self.image = pygame.image.load('assets/car.png').convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))
        self.image = pygame.transform.rotate(self.image, -90)  # 初始旋转到x轴方向

        self.friction = 0.01
        self.max_turn_angle = 28  # 最大转向角
        self.min_turn_angle = -28

        self.max_single_turn = 3

        self.move_center_x = 0
        self.move_center_y = 0

        self.drivable_r = 107  # 最小转弯半径

        self.reset()

    def reset(self, x_pos=300, y_pos=150, angle=math.pi / 2):
        self.x = x_pos
        self.y = y_pos
        forward_vec = np.array((math.cos(angle), -math.sin(angle), 0))
        forward_vec = (forward_vec * self.wheelbase) / 2
        self.x_h, self.y_h = self.x + forward_vec[0], self.y + forward_vec[1]
        self.x_b, self.y_b = self.x - forward_vec[0], self.y - forward_vec[1]
        self.vec_b_h = np.array((self.x_h - self.x_b, self.y_h - self.y_b, 0))

        self.speed = 0
        self.acceleration = 0

        self.turn_angle = 0
        self.angle_speed = 0

        self.rotated_image = pygame.transform.rotate(self.image, math.degrees(angle))  # 更新车头角度：360
        self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
        self.mask = pygame.mask.from_surface(self.rotated_image)

        self.forward_angle = math.degrees(angle)  # 角度朝向角360
        self.center_r, self.center_l, self.center_m = self.update_r_l_center_point()

    def update_forward_angle(self):
        vec_b_h = self.vec_b_h
        vec_x_axis = np.array((1, 0, 0))
        forward_angle = np.arccos(np.dot(vec_x_axis, vec_b_h) / (np.linalg.norm(vec_b_h) * np.linalg.norm(vec_x_axis)))
        left_or_right = np.cross(vec_x_axis, vec_b_h)[2]  # 右手定则
        if left_or_right < 0:
            forward_angle = forward_angle
        elif left_or_right > 0:
            forward_angle = -forward_angle
        forward_angle = math.degrees(forward_angle)
        return forward_angle

    def update_r_l_center_point(self):
        vec_y_axis = np.array((0, self.drivable_r, 0))
        angle = np.deg2rad(self.forward_angle)
        right = np.dot(vec_y_axis, self.matrix_3d_z(angle))
        self.center_r = [right[0] + self.x_b, right[1] + self.y_b]
        self.center_l = [-right[0] + self.x_b, -right[1] + self.y_b]
        self.center_m = [self.x_b, self.y_b]
        return self.center_r, self.center_l, self.center_m

    def matrix_3d_z(self, angle):
        matrix_z = np.array([[math.cos(angle), -math.sin(angle), 0], [math.sin(angle), math.cos(angle), 0], [0, 0, 1]])
        return matrix_z

    def get_unit_vec_BC(self):
        if self.turn_angle > 0:
            vec_center = np.dot(self.vec_b_h, self.matrix_3d_z(math.pi / 2))
        else:
            vec_center = np.dot(self.vec_b_h, self.matrix_3d_z(-math.pi / 2))
        unit_vec_b_c = vec_center / np.linalg.norm(vec_center)
        return unit_vec_b_c

    def update(self, action):
        steer, distanse, speed = action
        self.speed = speed
        self.turn_angle += steer * self.max_single_turn

        if steer > 0:
            self.turn_angle = min(self.turn_angle, self.max_turn_angle)
        elif steer < 0:
            self.turn_angle = max(self.turn_angle, self.min_turn_angle)

        angle_radians = math.radians(self.turn_angle)
        if angle_radians == 0:
            vec_bh_length = np.linalg.norm(self.vec_b_h)
            vec_move = (self.vec_b_h / vec_bh_length) * self.speed
            self.x_h, self.y_h = vec_move[0] + self.x_h, vec_move[1] + self.y_h
            self.x_b, self.y_b = vec_move[0] + self.x_b, vec_move[1] + self.y_b

        else:
            radius_ch = self.wheelbase / math.sin(angle_radians)
            radius_cb = self.wheelbase / math.tan(angle_radians)
            radius_ch = np.abs(radius_ch)
            radius_cb = np.abs(radius_cb)
            self.angle_speed = self.speed / radius_ch

            unit_vec_bc = self.get_unit_vec_BC()
            vec_bc = unit_vec_bc * radius_cb
            self.move_center_x, self.move_center_y = vec_bc[0] + self.x_b, vec_bc[1] + self.y_b

            vec_ch = np.array((self.x_h - self.move_center_x, self.y_h - self.move_center_y, 0))
            vec_cb = np.array((self.x_b - self.move_center_x, self.y_b - self.move_center_y, 0))
            if angle_radians > 0:  # 左转
                new_vec_ch = np.dot(vec_ch, self.matrix_3d_z(self.angle_speed))
                self.x_h, self.y_h = new_vec_ch[0] + self.move_center_x, new_vec_ch[1] + self.move_center_y
                new_vec_cb = np.dot(vec_cb, self.matrix_3d_z(self.angle_speed))
                self.x_b, self.y_b = new_vec_cb[0] + self.move_center_x, new_vec_cb[1] + self.move_center_y
            elif angle_radians < 0:
                new_vec_ch = np.dot(vec_ch, self.matrix_3d_z(-self.angle_speed))
                self.x_h, self.y_h = new_vec_ch[0] + self.move_center_x, new_vec_ch[1] + self.move_center_y
                new_vec_cb = np.dot(vec_cb, self.matrix_3d_z(-self.angle_speed))
                self.x_b, self.y_b = new_vec_cb[0] + self.move_center_x, new_vec_cb[1] + self.move_center_y

            new_x, new_y = (self.x_h + self.x_b) / 2, (self.y_h + self.y_b) / 2
            self.vec_b_h = np.array((self.x_h - self.x_b, self.y_h - self.y_b, 0))
            self.forward_angle = self.update_forward_angle()
            self.center_r, self.center_l, self.center_m = self.update_r_l_center_point()
            self.x, self.y = new_x, new_y

            self.rotated_image = pygame.transform.rotate(self.image, self.forward_angle)
            self.rect = self.rotated_image.get_rect(center=(self.x, self.y))
            self.mask = pygame.mask.from_surface(self.rotated_image)

    def draw(self):
        self.screen.blit(self.rotated_image, self.rect)
