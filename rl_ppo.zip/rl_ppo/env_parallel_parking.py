# -*- coding: utf-8 -*-

import pygame
import numpy as np
import math
import copy
from car import Car
from parked_car import ParkedCar, Boundary_rect, Parking_space, Line_rect
import gymnasium as gym

GRASS = pygame.image.load("assets/grass.jpeg")
CAR_LANE = pygame.image.load("assets/car_lane.jpg")


class Environment(gym.Env):

    def __init__(self):

        pygame.init()
        pygame.font.init()
        pygame.display.set_caption("parking")

        self.n_state = 9

        self.screen_width = 600
        self.screen_height = 400
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.bg_color = (230, 230, 230)

        self.n = 4
        self.action_space = gym.spaces.Discrete(4)
        self.observation_space = gym.spaces.Box(
            low=np.array([0, 0, -360]),
            high=np.array([400, 600, 360]),
            dtype=np.float32
        )

        self.max_episode_steps = 200
        self._max_episode_steps = self.max_episode_steps
        self.drivable_r = 107

        self.reset()

    def reset(self):

        # 确定车位的位置
        position = [284, 330, 90]
        self.target_location = position
        self.prev_info = None

        self.p0 = [position[0] - 22, position[1] - 48, 0]
        self.p1 = [position[0] + 22, position[1] - 48, 0]
        self.p2 = [position[0] + 22, position[1] + 48, 0]
        self.p3 = [position[0] + 22, position[1] + 48, 0]

        self.p_center_l = [position[0] - self.drivable_r, self.p0[1] - 15]
        self.p_center_r = [position[0] + self.drivable_r, self.p0[1] - 15]
        self.p_center_m = [(self.p_center_l[0] + self.p_center_r[0]) / 2, (self.p_center_l[1] + self.p_center_r[1]) / 2]

        base_point = position.copy()
        base_point[1] -= 100

        self.objects = pygame.sprite.Group()

        # 左侧竖线 & 右侧竖线
        Line_rect(94, [self.p0[0] - 4, 0.5 * (self.p0[1] + self.p3[1])], 'yellow', 90, self.objects)
        Line_rect(94, [self.p1[0] + 4, 0.5 * (self.p1[1] + self.p2[1])], 'yellow', 90, self.objects)

        # 左侧横线 & 右侧横线
        Line_rect(200, [self.p0[0] - 104, self.p0[1]], 'yellow', 0, self.objects)
        Line_rect(200, [self.p1[0] + 104, self.p1[1]], 'yellow', 0, self.objects)

        car_ready = False
        while (not car_ready):

            # 车辆的x，y，车头角度
            # init_x = np.random.uniform(500, 560)
            # init_y = np.random.uniform(160, 180)

            init_x = np.random.uniform(519, 520)
            init_y = np.random.uniform(170, 171)

            init_angle = np.random.uniform(0, 180)
            init_angle = np.deg2rad(init_angle)  # 转为弧度制
            self.car = Car(self.screen)
            self.car.reset(init_x, init_y, init_angle)
            car_ready = self.parking_ready()

        self.park_spc = Parking_space(self.screen, position, '#00FF00')
        self.target_distance = np.linalg.norm((self.park_spc.x - self.car.x, self.park_spc.y - self.car.y))
        self.max_dist = np.linalg.norm((self.park_spc.x - self.car.x, self.park_spc.y - self.car.y))
        self.min_distance = np.inf
        self.current_step = 0

        tmp = self.park_spc
        # pygame: (left, top), (width, height)
        # target_rect_1/2: 表示两个比较好的停车点的车中心位置
        self.target_rect_1 = pygame.Rect((tmp.target_x_1, tmp.target_y_1), (tmp.target_w, tmp.target_h))
        self.target_rect_2 = pygame.Rect((tmp.target_x_2, tmp.target_y_2), (tmp.target_w, tmp.target_h))
        self.reach_t_rect_1 = False

        # self._show_point(point=[tmp.target_x_1, tmp.target_y_1], color="red")

        self.right_place_flag = True
        self.right_point_flag = True
        self.right_point_angle_flag = True

        p0 = self.transform_axis(self.p0)
        p1 = self.transform_axis(self.p1)
        p2 = self.transform_axis(self.p2)
        p3 = self.transform_axis(self.p3)

        # 组装特征并且转换成1维
        state = [p0, p1, p2, p3]
        state = np.array(sum(state, []))
        state = np.append(state, self.car.turn_angle)

        return state

    def matrix_3d_z(self, angle):
        matrix_z = np.array([
            [math.cos(angle), -math.sin(angle), 0],
            [math.sin(angle), math.cos(angle), 0],
            [0, 0, 1]
        ])
        return matrix_z

    def sample(self):
        return [np.random.uniform() * 2 - 1]

    @staticmethod
    def calc_2_point(p1, p2):
        # 计算两个点之间的距离
        return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

    def parking_ready(self):
        case1 = self.calc_2_point(self.p_center_m, self.car.center_l) > self.drivable_r     # 车位点在车辆左侧之外
        case2 = self.calc_2_point(self.p_center_m, self.car.center_r) > self.drivable_r     # 车位点在车辆右侧之外

        case3 = self.calc_2_point(self.p_center_m, self.car.center_l) > self.drivable_r     # 车辆后轴在车位左侧之外
        case4 = self.calc_2_point(self.p_center_m, self.car.center_r) > self.drivable_r     # 车辆后轴在车位右侧之外

        case5 = self.calc_2_point(self.p_center_l, self.car.center_r) > 2 * self.drivable_r # 车位左圆和车位右圆不相交
        case6 = self.calc_2_point(self.p_center_r, self.car.center_l) > 2 * self.drivable_r # 车位右圆和车位左圆不相交

        park_ready = case1 & case2 & case3 & case4 & case5 & case6
        return park_ready

    def render(self, mode='human'):
        self.screen.fill('#99CCCC')
        self.screen.blit(GRASS, (0, 0))
        self.screen.blit(CAR_LANE, (0, -10))

        self.park_spc.draw(self.screen)

        self.objects.update()
        self.objects.draw(self.screen)

        self.car.draw()

        pygame.draw.line(self.screen, (0, 0, 255), (self.car.x, self.car.y), (self.park_spc.x, self.park_spc.y), 4)

        pygame.display.flip()

    def transform_axis(self, px):
        b_px = np.array([px[0] - self.car.x_b, px[1] - self.car.x_b, 0])
        trans_angle = math.radians(90 - self.car.forward_angle)
        b_px = np.dot(b_px, self.matrix_3d_z(trans_angle))
        res = [b_px[0], b_px[1]]
        return res

    def step(self, action, last_angle_gap=180):

        self.prev_info = [self.car.x, self.car.y, self.car.forward_angle]

        self.car.update(action)
        self.target_distance = np.linalg.norm((self.park_spc.x - self.car.x, self.park_spc.y - self.car.y))
        car_collision = bool(pygame.sprite.spritecollideany(self.car, self.objects, pygame.sprite.collide_mask))

        p0 = self.transform_axis(self.p0)
        p1 = self.transform_axis(self.p1)
        p2 = self.transform_axis(self.p2)
        p3 = self.transform_axis(self.p3)

        state = [p0, p1, p2, p3]
        state = np.array(sum(state, []))
        state = np.append(state, self.car.turn_angle)

        done, reward = False, 0

        self.current_step += 1
        # 如果超过了最大次数
        if self.current_step > self._max_episode_steps:
            done, reward = True, -8 - 0.2 * self.target_distance
        # 如果发生了撞车
        elif car_collision:
            done, reward = True, -5 - 0.2 * self.target_distance
        # 如果达到了停车位置
        elif self.reach_target():
            spc_angle = self.park_spc.forward_angle
            car_angle = self.car.forward_angle
            angle_distance = np.abs(spc_angle - car_angle)  # 角度制
            done, reward = True, 10 - 0.5 * angle_distance
            # raise
        else:
            reward, _ = self.calculate_detail_reward()

        return state, reward, done

    def calculate_detail_reward(self):
        # 计算更细致的reward

        # 计算角度相关的reward
        spc_angle = self.park_spc.forward_angle
        car_angle = self.car.forward_angle
        angle_distance = np.abs(spc_angle - car_angle) # 角度制

        # 计算距离相关的reward
        x, y = self.car.x, self.car.y
        target_x, target_y, _ = self.target_location
        dis_x, dis_y = abs(x - target_x), abs(y - target_y)

        max_angle, max_x, max_y = 180, 100, 100
        r1 = 2 - max(angle_distance / max_angle, dis_x / max_x, dis_y / max_y)

        # 计算距离和角度是否匹配
        target_angle = math.atan(- (target_y - y) / (target_x - x)) / math.pi * 180
        r2 = - abs(car_angle - target_angle)
        r2 = - r2 / 180

        # 计算和上一次的距离
        prev_x, prev_y, prev_angle = self.prev_info
        prev_dis = self.calc_2_point([prev_x, prev_y], [target_x, target_y])
        curr_dis = self.calc_2_point([x, y], [target_x, target_y])
        r3 = 0.1 if curr_dis < prev_dis else -0.5

        # reward = r1 + r2 + r3
        # reward = r3
        reward = r3

        return reward, [r1, r2, r3]

    @staticmethod
    def calculate_distance(ax, ay, bx, by):
        dis = (ax - bx) ** 2 + (ay - by) ** 2
        dis = math.sqrt(dis)
        return dis

    def reach_target(self):
        # 判断小车是否到达了车位
        in_right_place = self.park_spc.rect.collidepoint(self.car.x, self.car.y)
        in_right_point_1 = self.target_rect_1.collidepoint(self.car.x, self.car.y)
        in_right_point_2 = self.target_rect_2.collidepoint(self.car.x, self.car.y)

        spc_angle = self.park_spc.forward_angle
        car_angle = self.car.forward_angle
        in_right_angle = np.abs(spc_angle - car_angle) < 5

        if in_right_place or in_right_point_1 or in_right_point_2:
            reach_position = True
        else:
            reach_position = False

        return reach_position and in_right_angle


    def quit(self):
        pygame.quit()

    def _show_point(self, point, color="red"):
        # 用于画出一个X来展示point点
        Line_rect(30, point, color, 45, self.objects)
        Line_rect(30, point, color, -45, self.objects)


if __name__ == "__main__":

    env = Environment()
    clock = pygame.time.Clock()
    fps = 30
    running = True
    episode = 0
    total_steps = 0

    while running:
        state = env.reset()
        done = False
        episode_reward = 0
        episode += 1

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            angle = np.random.uniform() * 2 - 1
            action = [angle, 100, -3]
            next_state, reward, done = env.step(action)

            episode_reward += reward
            total_steps += 1

            env.render()
            clock.tick(fps)

            if done:
                print(f'轮次：{episode:8d}     本次奖励：{episode_reward:.2f}')
                break